//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DDIUTGgJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/list",
			"/scan",
			"/settings",
			"/bill/$id"
		],
		preloads: [
			"/assets/index-C5NY00YL.js",
			"/assets/store-th5sC07M.js",
			"/assets/useNavigate-vu8Cakz7.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C5NY00YL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Ch1n4LGe.js",
			"/assets/app-shell-BTNNWZIr.js",
			"/assets/bill-card-Voccz_kR.js",
			"/assets/button-BKJna_GF.js"
		]
	},
	"/list": {
		filePath: "/workspace/src/routes/list.tsx",
		children: void 0,
		preloads: [
			"/assets/list-CJeHW7Wt.js",
			"/assets/app-shell-BTNNWZIr.js",
			"/assets/bill-card-Voccz_kR.js"
		]
	},
	"/scan": {
		filePath: "/workspace/src/routes/scan.tsx",
		children: void 0,
		preloads: [
			"/assets/scan-Bw6W77iT.js",
			"/assets/app-shell-BTNNWZIr.js",
			"/assets/button-BKJna_GF.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-pyUUynIs.js",
			"/assets/app-shell-BTNNWZIr.js",
			"/assets/button-BKJna_GF.js"
		]
	},
	"/bill/$id": {
		filePath: "/workspace/src/routes/bill.$id.tsx",
		children: void 0,
		preloads: ["/assets/bill._id-CQo9jzeD.js", "/assets/button-BKJna_GF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
