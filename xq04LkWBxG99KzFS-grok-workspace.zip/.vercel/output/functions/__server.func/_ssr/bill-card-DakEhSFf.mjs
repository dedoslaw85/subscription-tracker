import { c as duePhrase, f as frequencyLabel, m as isSoon, u as formatGBP } from "./model-kam-k2-k.mjs";
import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useBills } from "./router-BK993T2q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bill-card-DakEhSFf.js
var import_jsx_runtime = require_jsx_runtime();
function BillCard({ bill }) {
	const hasReceipt = useBills((state) => state.receipts.some((receipt) => receipt.billId === bill.id));
	const meta = [
		bill.category,
		frequencyLabel(bill.frequency),
		hasReceipt ? "Receipt" : ""
	].filter(Boolean).join(" · ");
	const soon = isSoon(bill.nextDue);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/bill/$id",
		params: { id: bill.id },
		className: "block rounded-card border border-line bg-surface px-4 py-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 truncate text-lg text-fg",
				children: bill.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 tabular-nums text-fg",
				children: formatGBP(bill.amount)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-1 flex items-baseline justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 truncate text-muted",
				children: meta
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `shrink-0 ${soon ? "text-accent" : "text-muted"}`,
				children: duePhrase(bill.nextDue)
			})]
		})]
	});
}
//#endregion
export { BillCard as t };
