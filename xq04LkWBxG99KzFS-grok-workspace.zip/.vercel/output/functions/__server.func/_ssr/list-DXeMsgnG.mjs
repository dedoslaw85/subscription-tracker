import { i as __toESM } from "../_runtime.mjs";
import { f as frequencyLabel, l as filterBills, n as FREQUENCIES } from "./model-kam-k2-k.mjs";
import { C as require_jsx_runtime, X as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Plus } from "../_libs/lucide-react.mjs";
import { i as useBills } from "./router-BK993T2q.mjs";
import { t as AppShell } from "./app-shell-BtxYIl1f.mjs";
import { t as BillCard } from "./bill-card-DakEhSFf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/list-DXeMsgnG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = ["all", ...FREQUENCIES];
function filterLabel(filter) {
	return filter === "all" ? "All" : frequencyLabel(filter);
}
function BillList() {
	const bills = useBills((state) => state.bills);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const visible = filterBills(bills, filter);
	const countLabel = visible.length === 1 ? "1 bill" : `${visible.length} bills`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-8 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl text-fg",
					children: "All bills"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: countLabel
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/bill/$id",
					params: { id: "new" },
					className: "inline-flex h-11 items-center gap-1 rounded-control bg-accent px-4 text-on-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						size: 18,
						strokeWidth: 1.75,
						"aria-hidden": true
					}), "Add"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-wrap gap-2",
				role: "group",
				"aria-label": "Filter",
				children: FILTERS.map((item) => {
					const selected = item === filter;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": selected,
						onClick: () => setFilter(item),
						className: `h-11 rounded-control px-4 text-sm ${selected ? "bg-accent text-on-accent" : "border border-line bg-surface text-fg"}`,
						children: filterLabel(item)
					}, item);
				})
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-card border border-line bg-surface px-5 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg text-fg",
					children: "Nothing in this group"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-pretty text-muted",
					children: "Try another filter, or add a bill."
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 flex flex-col gap-3",
				children: visible.map((bill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillCard, { bill }) }, bill.id))
			})
		]
	}) });
}
//#endregion
export { BillList as component };
