import { i as __toESM } from "../_runtime.mjs";
import { E as suggestBill, T as sortReceipts, a as billCategoryFor, b as receiptFromScan, d as formatMoney, i as analyseMonth, p as isGbp, r as SPEND_CATEGORIES, s as createId, u as formatGBP, w as sortBills } from "./model-kam-k2-k.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Camera, s as ImagePlus } from "../_libs/lucide-react.mjs";
import { i as useBills } from "./router-BK993T2q.mjs";
import { t as Button } from "./button-CBrKE12v.mjs";
import { t as AppShell } from "./app-shell-BtxYIl1f.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-CU1WomrI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MAX_EDGE = 1400;
var MAX_CHARS = 15e5;
function loadImage(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const image = new Image();
		image.onload = () => {
			URL.revokeObjectURL(url);
			resolve(image);
		};
		image.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("unreadable"));
		};
		image.src = url;
	});
}
function exportJpeg(image, edge, quality) {
	const scale = Math.min(1, edge / Math.max(image.width, image.height));
	const width = Math.max(1, Math.round(image.width * scale));
	const height = Math.max(1, Math.round(image.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const context = canvas.getContext("2d");
	if (!context) throw new Error("canvas");
	context.drawImage(image, 0, 0, width, height);
	return canvas.toDataURL("image/jpeg", quality);
}
async function compressReceiptImage(file) {
	if (!file.type.startsWith("image/")) throw new Error("Choose a photo.");
	const image = await loadImage(file);
	let data = exportJpeg(image, MAX_EDGE, .72);
	if (data.length > MAX_CHARS) data = exportJpeg(image, 1100, .58);
	if (data.length > MAX_CHARS) data = exportJpeg(image, 800, .5);
	if (!data.startsWith("data:image/jpeg;base64,") || data.length > MAX_CHARS) throw new Error("That photo is too large. Try a closer picture.");
	return data;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var readReceipt = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object" || typeof input.image !== "string") return { image: "" };
	return { image: input.image };
}).handler(createSsrRpc("d5fadb2afc90d426498b4075ac0d95d624e014e1a22d9f6123d4cd3e2cc16325"));
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${now.getFullYear()}-${month}-${day}`;
}
function ScanScreen() {
	const bills = useBills((state) => state.bills);
	const receipts = useBills((state) => state.receipts);
	const addBill = useBills((state) => state.addBill);
	const addReceipt = useBills((state) => state.addReceipt);
	const updateReceipt = useBills((state) => state.updateReceipt);
	const removeReceipt = useBills((state) => state.removeReceipt);
	const navigate = useNavigate();
	const cameraRef = (0, import_react.useRef)(null);
	const libraryRef = (0, import_react.useRef)(null);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [reading, setReading] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)("");
	const [focusId, setFocusId] = (0, import_react.useState)(null);
	const [manualName, setManualName] = (0, import_react.useState)("");
	const [manualAmount, setManualAmount] = (0, import_react.useState)("");
	const [manualCategory, setManualCategory] = (0, import_react.useState)("Groceries");
	const [manualDate, setManualDate] = (0, import_react.useState)(todayIso());
	const focus = receipts.find((receipt) => receipt.id === focusId) ?? null;
	const spend = analyseMonth(receipts);
	const recent = sortReceipts(receipts);
	async function onFile(file) {
		if (!file) return;
		setNotice("");
		setFailed(false);
		setFocusId(null);
		try {
			const image = await compressReceiptImage(file);
			setDraft(image);
		} catch (error) {
			setDraft(null);
			setNotice(error instanceof Error ? error.message : "That photo couldn’t be opened.");
		}
	}
	async function read() {
		if (!draft || reading) return;
		setReading(true);
		setNotice("");
		setFailed(false);
		try {
			const result = await readReceipt({ data: { image: draft } });
			if (!result.ok) {
				setFailed(true);
				setNotice(result.error);
				return;
			}
			if (!result.receipt.readable) {
				setFailed(true);
				setNotice(result.receipt.summary);
				if (result.receipt.merchant) setManualName(result.receipt.merchant);
				return;
			}
			const receipt = receiptFromScan(result.receipt, draft);
			addReceipt(receipt);
			setFocusId(receipt.id);
			setDraft(null);
			setNotice("");
		} catch {
			setFailed(true);
			setNotice("That photo couldn’t be read. Try again in a moment.");
		} finally {
			setReading(false);
		}
	}
	function saveManual() {
		const trimmed = manualName.trim();
		const parsed = Number(manualAmount.replace(/[£,\s]/g, ""));
		if (!trimmed) {
			setNotice("Add the shop or bill name.");
			return;
		}
		if (!Number.isFinite(parsed) || parsed <= 0 || parsed > 1e6) {
			setNotice("Enter an amount greater than zero.");
			return;
		}
		const receipt = {
			id: createId(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			merchant: trimmed.slice(0, 80),
			date: manualDate,
			total: Math.round(parsed * 100) / 100,
			currency: "GBP",
			category: manualCategory || "Other",
			summary: `${trimmed} for ${formatGBP(Math.round(parsed * 100) / 100)}, saved from the photo.`,
			recurring: false,
			frequency: null,
			items: [],
			billId: null,
			image: draft ?? "",
			source: "manual"
		};
		addReceipt(receipt);
		setFocusId(receipt.id);
		setDraft(null);
		setFailed(false);
		setNotice("");
		setManualName("");
		setManualAmount("");
	}
	function trackAsBill(receipt) {
		if (!isFiniteBill(receipt)) return;
		const frequency = receipt.frequency ?? "monthly";
		const bill = {
			id: createId(),
			name: receipt.merchant.slice(0, 60) || "Receipt",
			amount: receipt.total,
			frequency,
			nextDue: receipt.date || todayIso(),
			category: billCategoryFor(receipt.category)
		};
		addBill(bill);
		updateReceipt(receipt.id, {
			billId: bill.id,
			recurring: true,
			frequency
		});
		navigate({
			to: "/bill/$id",
			params: { id: bill.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		action: draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => void read(),
			disabled: reading,
			children: reading ? "Reading…" : "Read receipt"
		}) : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 pt-8 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl text-fg",
					children: "Read a receipt"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-pretty text-muted",
					children: "Take a photo. It’s read, summarised, and saved with your spending."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: cameraRef,
					type: "file",
					accept: "image/*",
					capture: "environment",
					className: "sr-only",
					onChange: (event) => {
						const file = event.target.files?.[0];
						event.target.value = "";
						onFile(file);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: libraryRef,
					type: "file",
					accept: "image/jpeg,image/png,image/webp,image/*",
					className: "sr-only",
					onChange: (event) => {
						const file = event.target.files?.[0];
						event.target.value = "";
						onFile(file);
					}
				}),
				draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: draft,
						alt: "Receipt to read",
						className: "max-h-72 w-full rounded-card bg-surface object-contain outline outline-1 -outline-offset-1 outline-line"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => cameraRef.current?.click(),
							disabled: reading,
							children: "Retake"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => libraryRef.current?.click(),
							disabled: reading,
							children: "Choose another"
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => cameraRef.current?.click(),
						className: "flex min-h-28 flex-col items-center justify-center gap-2 rounded-card border border-line bg-surface px-3 text-fg shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
							size: 22,
							strokeWidth: 1.75,
							"aria-hidden": true
						}), "Take photo"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => libraryRef.current?.click(),
						className: "flex min-h-28 flex-col items-center justify-center gap-2 rounded-card border border-line bg-surface px-3 text-fg shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
							size: 22,
							strokeWidth: 1.75,
							"aria-hidden": true
						}), "Choose photo"]
					})]
				}),
				notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-card bg-accent-soft px-4 py-3 text-sm text-pretty text-accent-ink",
					role: "status",
					children: notice
				}) : null,
				failed && draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 flex flex-col gap-4",
					onSubmit: (event) => {
						event.preventDefault();
						saveManual();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Type the receipt in, and it still joins this month’s spending."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							htmlFor: "manual-name",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "manual-name",
								value: manualName,
								onChange: (event) => setManualName(event.target.value),
								maxLength: 80,
								placeholder: "Corner shop",
								className: "h-14 w-full rounded-control border border-line bg-surface px-4 text-base outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							htmlFor: "manual-amount",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Amount"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex h-14 items-center rounded-control border border-line bg-surface px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									"aria-hidden": true,
									children: "£"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "manual-amount",
									value: manualAmount,
									onChange: (event) => setManualAmount(event.target.value.replace(/[^\d.]/g, "")),
									inputMode: "decimal",
									placeholder: "0.00",
									className: "w-full bg-transparent pl-2 text-base tabular-nums outline-none"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							htmlFor: "manual-category",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Category"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "manual-category",
								value: manualCategory,
								onChange: (event) => setManualCategory(event.target.value),
								className: "h-14 w-full rounded-control border border-line bg-surface px-4 text-base outline-none",
								children: SPEND_CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: item
								}, item))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex flex-col gap-2",
							htmlFor: "manual-date",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "manual-date",
								type: "date",
								value: manualDate,
								onChange: (event) => setManualDate(event.target.value),
								className: "h-14 w-full rounded-control border border-line bg-surface px-4 text-base outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Save to spending"
						})
					]
				}) : null,
				focus ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptDetail, {
					receipt: focus,
					bills,
					onChange: (patch) => updateReceipt(focus.id, patch),
					onDelete: () => {
						removeReceipt(focus.id);
						setFocusId(null);
					},
					onTrack: () => trackAsBill(focus)
				}, focus.id) : null,
				receipts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendPanel, { spend }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-10 text-lg text-fg",
						children: "Saved receipts"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-3",
						children: recent.map((receipt) => {
							const open = receipt.id === focusId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-expanded": open,
								onClick: () => {
									setDraft(null);
									setFailed(false);
									setNotice("");
									setFocusId(open ? null : receipt.id);
								},
								className: `w-full rounded-card border px-4 py-4 text-left shadow-card ${open ? "border-accent bg-accent-soft" : "border-line bg-surface"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 truncate text-lg text-fg",
										children: receipt.merchant
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0 tabular-nums text-fg",
										children: formatMoney(receipt.total, receipt.currency)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 flex items-baseline justify-between gap-3 text-sm text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 truncate",
										children: receipt.category
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0",
										children: receipt.date || "No date"
									})]
								})]
							}) }, receipt.id);
						})
					})
				] }) : null
			]
		})
	});
}
function isFiniteBill(receipt) {
	return receipt.merchant.trim().length > 0 && receipt.total > 0;
}
function ReceiptDetail({ receipt, bills, onChange, onDelete, onTrack }) {
	const [amount, setAmount] = (0, import_react.useState)(String(receipt.total));
	const [merchant, setMerchant] = (0, import_react.useState)(receipt.merchant);
	const [askDelete, setAskDelete] = (0, import_react.useState)(false);
	const suggestion = suggestBill(receipt.merchant, bills);
	const linked = bills.find((bill) => bill.id === receipt.billId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 rounded-card border border-line bg-surface px-4 py-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					receipt.source === "scan" ? "Saved to spending" : "Saved by hand",
					" · ",
					receipt.category
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-pretty text-fg",
				children: receipt.summary
			}),
			!isGbp(receipt.currency) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "This one isn’t in pounds, so it stays out of the monthly total."
			}) : null,
			receipt.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: receipt.image,
				alt: "",
				className: "mt-4 max-h-72 w-full rounded-control bg-bg object-contain outline outline-1 -outline-offset-1 outline-line"
			}) : null,
			receipt.items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2 border-t border-line pt-4",
				children: receipt.items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 text-fg",
						children: [item.name, item.quantity != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" × ", item.quantity]
						}) : null]
					}), item.amount != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 tabular-nums text-muted",
						children: formatMoney(item.amount, receipt.currency)
					}) : null]
				}, `${item.name}-${index}`))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-4 border-t border-line pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2",
						htmlFor: `merchant-${receipt.id}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: `merchant-${receipt.id}`,
							value: merchant,
							onChange: (event) => setMerchant(event.target.value),
							onBlur: () => {
								const next = merchant.trim().slice(0, 80);
								if (next && next !== receipt.merchant) onChange({ merchant: next });
								else setMerchant(receipt.merchant);
							},
							className: "h-14 w-full rounded-control border border-line bg-bg px-4 text-base outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2",
						htmlFor: `amount-${receipt.id}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Amount"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: `amount-${receipt.id}`,
							value: amount,
							inputMode: "decimal",
							onChange: (event) => setAmount(event.target.value.replace(/[^\d.]/g, "")),
							onBlur: () => {
								const parsed = Number(amount);
								if (Number.isFinite(parsed) && parsed > 0 && parsed <= 1e6) {
									const total = Math.round(parsed * 100) / 100;
									if (total !== receipt.total) onChange({ total });
									setAmount(String(total));
								} else setAmount(String(receipt.total));
							},
							className: "h-14 w-full rounded-control border border-line bg-bg px-4 text-base tabular-nums outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2",
						htmlFor: `category-${receipt.id}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: `category-${receipt.id}`,
							value: SPEND_CATEGORIES.includes(receipt.category) ? receipt.category : "Other",
							onChange: (event) => onChange({ category: event.target.value }),
							className: "h-14 w-full rounded-control border border-line bg-bg px-4 text-base outline-none",
							children: SPEND_CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2",
						htmlFor: `date-${receipt.id}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: `date-${receipt.id}`,
							type: "date",
							value: receipt.date,
							onChange: (event) => onChange({ date: event.target.value }),
							className: "h-14 w-full rounded-control border border-line bg-bg px-4 text-base outline-none"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-3",
				children: [
					linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Attached to ",
							linked.name,
							". The monthly bill total stays as it is."
						]
					}) : suggestion ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => onChange({ billId: suggestion.id }),
						children: ["Attach to ", suggestion.name]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-col gap-2",
						htmlFor: `bill-${receipt.id}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Bill"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: `bill-${receipt.id}`,
							value: receipt.billId ?? "",
							onChange: (event) => onChange({ billId: event.target.value || null }),
							className: "h-14 w-full rounded-control border border-line bg-bg px-4 text-base outline-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Not attached"
							}), sortBills(bills).map((bill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: bill.id,
								children: bill.name
							}, bill.id))]
						})]
					}),
					!linked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: suggestion ? "quiet" : "primary",
						onClick: onTrack,
						children: "Track as a recurring bill"
					}) : null,
					askDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Delete this receipt? The photo goes with it."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: onDelete,
							children: "Delete"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setAskDelete(false),
							children: "Keep"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "subtle",
						onClick: () => setAskDelete(true),
						children: "Delete this receipt"
					})
				]
			})
		]
	});
}
function SpendPanel({ spend }) {
	const peak = spend.categories[0]?.total ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg text-fg",
				children: spend.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-3xl tracking-tight text-fg tabular-nums",
				children: formatGBP(spend.total)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-pretty text-muted",
				children: [
					spend.count === 1 ? "1 receipt" : `${spend.count} receipts`,
					spend.linked > 0 ? ` · ${formatGBP(spend.linked)} already on a bill` : "",
					spend.extra > 0 && spend.linked > 0 ? ` · ${formatGBP(spend.extra)} not linked` : "",
					spend.otherCurrencies > 0 ? ` · ${spend.otherCurrencies === 1 ? "1 receipt in another currency isn’t" : `${spend.otherCurrencies} receipts in other currencies aren’t`} in this total` : ""
				]
			}),
			spend.categories.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-3",
				children: spend.categories.map((slice) => {
					const width = peak > 0 ? Math.max(8, Math.round(slice.total / peak * 100)) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: slice.category
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-muted",
							children: formatGBP(slice.total)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-2 overflow-hidden rounded-full bg-accent-soft",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 rounded-full bg-accent",
							style: { width: `${width}%` }
						})
					})] }, slice.category);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "No pound totals in this month yet."
			})
		]
	});
}
//#endregion
export { ScanScreen as component };
