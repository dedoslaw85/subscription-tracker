import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-DNxA6piH.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var readReceipt_createServerFn_handler = createServerRpc({
	id: "d5fadb2afc90d426498b4075ac0d95d624e014e1a22d9f6123d4cd3e2cc16325",
	name: "readReceipt",
	filename: "src/lib/receipts/scan.ts"
}, (opts) => readReceipt.__executeServer(opts));
var readReceipt = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object" || typeof input.image !== "string") return { image: "" };
	return { image: input.image };
}).handler(readReceipt_createServerFn_handler, async ({ data }) => {
	const image = data.image;
	if (!image.startsWith("data:image/jpeg;base64,") && !image.startsWith("data:image/png;base64,")) return {
		ok: false,
		error: "Use a JPEG or PNG photo of the receipt."
	};
	if (image.length > 18e5) return {
		ok: false,
		error: "That photo is too large. Try a closer picture."
	};
	const { readWithGrok } = await import("./scan.server-D_xN8d_e.mjs");
	return readWithGrok(image);
});
//#endregion
export { readReceipt_createServerFn_handler };
