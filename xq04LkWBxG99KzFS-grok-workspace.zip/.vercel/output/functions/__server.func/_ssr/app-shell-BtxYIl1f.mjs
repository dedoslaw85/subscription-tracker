import { C as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as List, c as House, n as Settings, o as Leaf, r as ScanLine } from "../_libs/lucide-react.mjs";
import { i as useBills } from "./router-BK993T2q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-BtxYIl1f.js
var import_jsx_runtime = require_jsx_runtime();
function BannerAd() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "safe-bottom shrink-0 border-t border-line bg-surface px-4 pt-3",
		"aria-label": "Advertisement",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-11 shrink-0 place-items-center rounded-control bg-accent-soft text-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
					size: 20,
					strokeWidth: 1.75,
					"aria-hidden": true
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide text-muted uppercase",
						children: "Ad"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-base text-fg",
						children: "Fieldnote tea"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						children: "A quiet cup, delivered once a month."
					})
				]
			})]
		})
	});
}
function Tab({ to, label, icon: Icon }) {
	const active = useRouterState({ select: (state) => state.location.pathname }) === to;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		"aria-current": active ? "page" : void 0,
		className: `flex min-h-14 flex-1 flex-col items-center justify-center gap-1 text-sm ${active ? "text-accent" : "text-muted"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			size: 22,
			strokeWidth: 1.75,
			"aria-hidden": true
		}), label]
	});
}
function AppShell({ children, action }) {
	const adsRemoved = useBills((state) => state.adsRemoved);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-xl flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-h-0 flex-1 overflow-y-auto",
				children
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 px-5 pt-3 pb-3",
				children: action
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: `shrink-0 border-t border-line bg-surface ${adsRemoved ? "safe-bottom" : ""}`,
				"aria-label": "Primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tab, {
							to: "/",
							label: "Home",
							icon: House
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tab, {
							to: "/list",
							label: "List",
							icon: List
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tab, {
							to: "/scan",
							label: "AI",
							icon: ScanLine
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tab, {
							to: "/settings",
							label: "Settings",
							icon: Settings
						})
					]
				})
			}),
			adsRemoved ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BannerAd, {})
		]
	});
}
//#endregion
export { AppShell as t };
