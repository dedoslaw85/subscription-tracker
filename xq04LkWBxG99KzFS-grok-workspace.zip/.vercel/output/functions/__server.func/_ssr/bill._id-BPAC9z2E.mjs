import { i as __toESM } from "../_runtime.mjs";
import { T as sortReceipts, d as formatMoney, f as frequencyLabel, h as monthlyCost, n as FREQUENCIES, s as createId, t as CATEGORIES, u as formatGBP, v as parseAmount } from "./model-kam-k2-k.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useBills, n as Route } from "./router-BK993T2q.mjs";
import { t as Button } from "./button-CBrKE12v.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bill._id-BPAC9z2E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	const month = String(now.getMonth() + 1).padStart(2, "0");
	const day = String(now.getDate()).padStart(2, "0");
	return `${now.getFullYear()}-${month}-${day}`;
}
function BillScreen() {
	const { id } = Route.useParams();
	const isNew = id === "new";
	const existing = useBills((state) => state.bills.find((bill) => bill.id === id));
	const addBill = useBills((state) => state.addBill);
	const updateBill = useBills((state) => state.updateBill);
	const removeBill = useBills((state) => state.removeBill);
	const receipts = useBills((state) => state.receipts);
	const navigate = useNavigate();
	const router = useRouter();
	const [name, setName] = (0, import_react.useState)(existing?.name ?? "");
	const [amount, setAmount] = (0, import_react.useState)(existing ? String(existing.amount) : "");
	const [frequency, setFrequency] = (0, import_react.useState)(existing?.frequency ?? "monthly");
	const [nextDue, setNextDue] = (0, import_react.useState)(existing?.nextDue ?? todayIso());
	const [category, setCategory] = (0, import_react.useState)(existing?.category ?? "");
	const [error, setError] = (0, import_react.useState)("");
	const [askDelete, setAskDelete] = (0, import_react.useState)(false);
	function leave() {
		if (typeof window !== "undefined" && window.history.length > 1) {
			router.history.back();
			return;
		}
		navigate({ to: "/" });
	}
	function save() {
		const trimmed = name.trim();
		const parsed = parseAmount(amount);
		if (!trimmed) {
			setError("Add a name.");
			return;
		}
		if (parsed == null) {
			setError("Enter an amount greater than zero.");
			return;
		}
		if (!nextDue) {
			setError("Choose the next due date.");
			return;
		}
		const bill = {
			id: existing?.id ?? createId(),
			name: trimmed.slice(0, 60),
			amount: parsed,
			frequency,
			nextDue,
			category
		};
		if (existing) updateBill(existing.id, bill);
		else addBill(bill);
		leave();
	}
	if (!isNew && !existing) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex h-dvh w-full max-w-xl flex-col justify-center bg-bg px-5 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl",
				children: "This bill is gone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "It may have been deleted on this device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6",
				onClick: () => void navigate({ to: "/list" }),
				children: "Back to the list"
			})
		]
	});
	const parsed = parseAmount(amount);
	const monthHint = parsed != null && frequency !== "monthly" ? `About ${formatGBP(monthlyCost(parsed, frequency))} a month` : "Counted in the monthly total on Home.";
	const linked = existing ? sortReceipts(receipts.filter((receipt) => receipt.billId === existing.id)) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex h-dvh w-full max-w-xl flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "shrink-0 px-5 pt-8 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl",
				children: isNew ? "Add a bill" : "Edit bill"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Name, amount, how often, and the next date."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex min-h-0 flex-1 flex-col gap-6 overflow-x-hidden overflow-y-auto px-5 pt-4 pb-8",
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2",
					htmlFor: "bill-name",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "bill-name",
						value: name,
						onChange: (event) => setName(event.target.value),
						maxLength: 60,
						autoComplete: "off",
						placeholder: "Electricity",
						className: "h-14 w-full min-w-0 max-w-full rounded-control border border-line bg-surface px-4 text-base outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2",
					htmlFor: "bill-amount",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Amount"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex h-14 min-w-0 items-center rounded-control border border-line bg-surface px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							"aria-hidden": true,
							children: "£"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "bill-amount",
							value: amount,
							onChange: (event) => setAmount(event.target.value.replace(/[^\d.]/g, "")),
							inputMode: "decimal",
							autoComplete: "off",
							placeholder: "0.00",
							className: "w-full bg-transparent pl-2 text-base tabular-nums outline-none"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm",
							children: "Frequency"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: FREQUENCIES.map((item) => {
								const selected = item === frequency;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": selected,
									onClick: () => setFrequency(item),
									className: `h-14 rounded-control text-base ${selected ? "bg-accent text-on-accent" : "border border-line bg-surface text-fg"}`,
									children: frequencyLabel(item)
								}, item);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: monthHint
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2",
					htmlFor: "bill-due",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Next due date"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "bill-due",
						type: "date",
						value: nextDue,
						onChange: (event) => setNextDue(event.target.value),
						className: "h-14 w-full min-w-0 max-w-full rounded-control border border-line bg-surface px-4 text-base outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-col gap-2",
					htmlFor: "bill-category",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm",
						children: ["Category ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "optional"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "bill-category",
						value: category,
						onChange: (event) => setCategory(event.target.value),
						className: "h-14 w-full min-w-0 max-w-full rounded-control border border-line bg-surface px-4 text-base outline-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "None"
						}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: item
						}, item))]
					})]
				}),
				linked.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm",
						children: "Receipts"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: linked.map((receipt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 rounded-control border border-line bg-surface px-3 py-3",
							children: [
								receipt.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: receipt.image,
									alt: "",
									className: "h-14 w-11 shrink-0 rounded-control object-cover outline outline-1 -outline-offset-1 outline-line"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-base text-fg",
										children: receipt.merchant
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm text-muted",
										children: [receipt.date || "No date", receipt.category].filter(Boolean).join(" · ")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 tabular-nums text-fg",
									children: formatMoney(receipt.total, receipt.currency)
								})
							]
						}, receipt.id))
					})]
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-accent-ink",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-auto flex flex-col gap-3 pt-2",
					children: askDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Delete ",
								existing?.name,
								"? This can’t be undone."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								if (existing) removeBill(existing.id);
								leave();
							},
							children: "Delete"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setAskDelete(false),
							children: "Keep"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Save"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: leave,
							children: "Cancel"
						}),
						existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "subtle",
							onClick: () => setAskDelete(true),
							children: "Delete this bill"
						}) : null
					] })
				})
			]
		})]
	});
}
//#endregion
export { BillScreen as component };
