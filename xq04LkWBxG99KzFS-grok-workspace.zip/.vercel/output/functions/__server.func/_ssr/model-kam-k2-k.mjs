import { a as addYears, c as startOfDay, i as format, l as addMonths, n as parseISO, o as addWeeks, r as isBefore, s as differenceInCalendarDays, t as enGB, u as addDays } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/model-kam-k2-k.js
var FREQUENCIES = [
	"weekly",
	"monthly",
	"yearly"
];
var CATEGORIES = [
	"Streaming",
	"Music",
	"Utilities",
	"Insurance",
	"Health",
	"Software",
	"Home",
	"Other"
];
function createId() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `bill-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function frequencyLabel(frequency) {
	if (frequency === "weekly") return "Weekly";
	if (frequency === "yearly") return "Yearly";
	return "Monthly";
}
function formatGBP(amount) {
	return new Intl.NumberFormat("en-GB", {
		style: "currency",
		currency: "GBP"
	}).format(amount);
}
function monthlyCost(amount, frequency) {
	if (frequency === "weekly") return amount * 52 / 12;
	if (frequency === "yearly") return amount / 12;
	return amount;
}
function monthlyTotal(bills) {
	return bills.reduce((sum, bill) => sum + monthlyCost(bill.amount, bill.frequency), 0);
}
function step(date, frequency) {
	if (frequency === "weekly") return addWeeks(date, 1);
	if (frequency === "yearly") return addYears(date, 1);
	return addMonths(date, 1);
}
function normalizeBill(bill, today = startOfDay(/* @__PURE__ */ new Date())) {
	const parsed = parseISO(bill.nextDue);
	if (Number.isNaN(parsed.getTime())) return {
		...bill,
		nextDue: format(today, "yyyy-MM-dd")
	};
	let cursor = startOfDay(parsed);
	let guard = 0;
	while (isBefore(cursor, today) && guard < 600) {
		cursor = step(cursor, bill.frequency);
		guard += 1;
	}
	const nextDue = format(cursor, "yyyy-MM-dd");
	return nextDue === bill.nextDue ? bill : {
		...bill,
		nextDue
	};
}
function duePhrase(iso, today = startOfDay(/* @__PURE__ */ new Date())) {
	const date = startOfDay(parseISO(iso));
	if (Number.isNaN(date.getTime())) return "No date";
	const formatted = format(date, "d MMM", { locale: enGB });
	const days = differenceInCalendarDays(date, today);
	if (days === 0) return `Today, ${formatted}`;
	if (days === 1) return `Tomorrow, ${formatted}`;
	return formatted;
}
function isSoon(iso, today = startOfDay(/* @__PURE__ */ new Date())) {
	const date = startOfDay(parseISO(iso));
	if (Number.isNaN(date.getTime())) return false;
	const days = differenceInCalendarDays(date, today);
	return days === 0 || days === 1;
}
function sortBills(bills) {
	return [...bills].sort((a, b) => a.nextDue.localeCompare(b.nextDue) || a.name.localeCompare(b.name));
}
function filterBills(bills, filter) {
	return sortBills(filter === "all" ? bills : bills.filter((bill) => bill.frequency === filter));
}
function sampleBills(today = startOfDay(/* @__PURE__ */ new Date())) {
	const due = (days) => format(addDays(today, days), "yyyy-MM-dd");
	return [
		{
			id: createId(),
			name: "Electricity",
			amount: 68,
			frequency: "monthly",
			nextDue: due(1),
			category: "Utilities"
		},
		{
			id: createId(),
			name: "Netflix",
			amount: 10.99,
			frequency: "monthly",
			nextDue: due(3),
			category: "Streaming"
		},
		{
			id: createId(),
			name: "Coffee club",
			amount: 4.5,
			frequency: "weekly",
			nextDue: due(4),
			category: "Other"
		},
		{
			id: createId(),
			name: "Spotify",
			amount: 11.99,
			frequency: "monthly",
			nextDue: due(8),
			category: "Music"
		},
		{
			id: createId(),
			name: "Gym",
			amount: 32,
			frequency: "monthly",
			nextDue: due(12),
			category: "Health"
		},
		{
			id: createId(),
			name: "Cloud storage",
			amount: 2.99,
			frequency: "monthly",
			nextDue: due(20),
			category: "Software"
		},
		{
			id: createId(),
			name: "Home insurance",
			amount: 186,
			frequency: "yearly",
			nextDue: due(40),
			category: "Insurance"
		}
	];
}
function parseAmount(raw) {
	const cleaned = raw.trim().replace(/£/g, "").replace(/,/g, "");
	if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
	const value = Number(cleaned);
	if (!Number.isFinite(value) || value <= 0 || value > 1e6) return null;
	return Math.round(value * 100) / 100;
}
function sanitizeBill(value) {
	if (!value || typeof value !== "object") return null;
	const bill = value;
	if (typeof bill.id !== "string" || typeof bill.name !== "string") return null;
	if (typeof bill.amount !== "number" || !Number.isFinite(bill.amount)) return null;
	if (bill.frequency !== "weekly" && bill.frequency !== "monthly" && bill.frequency !== "yearly") return null;
	if (typeof bill.nextDue !== "string") return null;
	return {
		id: bill.id,
		name: bill.name,
		amount: bill.amount,
		frequency: bill.frequency,
		nextDue: bill.nextDue,
		category: typeof bill.category === "string" ? bill.category : ""
	};
}
function billsDueSoon(bills, today = startOfDay(/* @__PURE__ */ new Date())) {
	return sortBills(bills).filter((bill) => isSoon(bill.nextDue, today));
}
var SPEND_CATEGORIES = [
	"Groceries",
	"Dining",
	"Transport",
	"Shopping",
	"Fuel",
	"Utilities",
	"Health",
	"Home",
	"Entertainment",
	"Subscriptions",
	"Other"
];
var BILL_CATEGORY = {
	Utilities: "Utilities",
	Health: "Health",
	Home: "Home",
	Entertainment: "Streaming",
	Subscriptions: "Software"
};
function isGbp(currency) {
	const code = currency.trim().toUpperCase();
	return code === "" || code === "GBP" || code === "£";
}
function formatMoney(amount, currency) {
	if (isGbp(currency)) return formatGBP(amount);
	const code = currency.trim().toUpperCase();
	try {
		return new Intl.NumberFormat("en-GB", {
			style: "currency",
			currency: code
		}).format(amount);
	} catch {
		return `${code} ${amount.toFixed(2)}`;
	}
}
function billCategoryFor(category) {
	return BILL_CATEGORY[category] ?? "Other";
}
function roundMoney(value) {
	return Math.round(value * 100) / 100;
}
function asMoney(value) {
	const raw = typeof value === "number" ? value : typeof value === "string" ? Number(value.replace(/[£$€,\s]/g, "")) : NaN;
	if (!Number.isFinite(raw) || raw <= 0 || raw > 1e6) return 0;
	return roundMoney(raw);
}
function asDate(value) {
	if (typeof value !== "string") return "";
	const match = value.trim().match(/^(\d{4})-(\d{2})-(\d{2})/);
	if (!match) return "";
	const iso = `${match[1]}-${match[2]}-${match[3]}`;
	const parsed = parseISO(iso);
	if (Number.isNaN(parsed.getTime())) return "";
	return iso;
}
function asCategory(value) {
	if (typeof value !== "string") return "Other";
	return SPEND_CATEGORIES.find((item) => item.toLowerCase() === value.trim().toLowerCase()) ?? "Other";
}
function asCurrency(value) {
	if (typeof value !== "string") return "GBP";
	const code = value.trim().toUpperCase();
	if (code === "" || code === "£" || code === "GBP") return "GBP";
	return /^[A-Z]{3}$/.test(code) ? code : "GBP";
}
function asFrequency(value) {
	if (value === "weekly" || value === "monthly" || value === "yearly") return value;
	return null;
}
function asItems(value) {
	if (!Array.isArray(value)) return [];
	const items = [];
	for (const entry of value) {
		if (!entry || typeof entry !== "object") continue;
		const record = entry;
		const name = typeof record.name === "string" ? record.name.trim().slice(0, 80) : "";
		if (!name) continue;
		const quantity = typeof record.quantity === "number" && Number.isFinite(record.quantity) && record.quantity > 0 ? roundMoney(record.quantity) : null;
		const amount = typeof record.amount === "number" && Number.isFinite(record.amount) && record.amount >= 0 && record.amount <= 1e6 ? roundMoney(record.amount) : null;
		items.push({
			name,
			quantity,
			amount
		});
		if (items.length >= 25) break;
	}
	return items;
}
function parseScannedReceipt(value) {
	if (!value || typeof value !== "object") return null;
	const record = value;
	const merchant = typeof record.merchant === "string" ? record.merchant.trim().slice(0, 80) : "";
	const total = asMoney(record.total);
	const items = asItems(record.items);
	let summary = typeof record.summary === "string" ? record.summary.trim().slice(0, 400) : "";
	const frequency = asFrequency(record.frequency);
	const readable = record.readable === true && total > 0;
	if (!summary) summary = readable ? `${merchant || "This receipt"} came to ${formatMoney(total, asCurrency(record.currency))}.` : "This photo couldn’t be read as a receipt.";
	return {
		readable,
		merchant,
		date: asDate(record.date),
		total,
		currency: asCurrency(record.currency),
		category: asCategory(record.category),
		summary,
		recurring: record.recurring === true || frequency != null,
		frequency,
		items
	};
}
function parseModelJson(text) {
	const trimmed = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
	let value;
	try {
		value = JSON.parse(trimmed);
	} catch {
		const start = trimmed.indexOf("{");
		const end = trimmed.lastIndexOf("}");
		if (start < 0 || end <= start) return null;
		try {
			value = JSON.parse(trimmed.slice(start, end + 1));
		} catch {
			return null;
		}
	}
	return parseScannedReceipt(value);
}
function cleanImage(value) {
	if (typeof value !== "string") return "";
	if (value.length > 18e5) return "";
	if (value.startsWith("data:image/jpeg;base64,") || value.startsWith("data:image/png;base64,")) return value;
	return "";
}
function sanitizeReceipt(value) {
	if (!value || typeof value !== "object") return null;
	const record = value;
	if (typeof record.id !== "string" || typeof record.merchant !== "string") return null;
	if (typeof record.total !== "number" || !Number.isFinite(record.total) || record.total <= 0) return null;
	if (typeof record.createdAt !== "string") return null;
	const frequency = asFrequency(record.frequency);
	return {
		id: record.id,
		createdAt: record.createdAt,
		merchant: record.merchant.slice(0, 80),
		date: asDate(record.date),
		total: roundMoney(record.total),
		currency: asCurrency(record.currency),
		category: asCategory(record.category),
		summary: typeof record.summary === "string" ? record.summary.slice(0, 400) : "",
		recurring: record.recurring === true || frequency != null,
		frequency,
		items: asItems(record.items),
		billId: typeof record.billId === "string" ? record.billId : null,
		image: cleanImage(record.image),
		source: record.source === "manual" ? "manual" : "scan"
	};
}
function trimReceipts(receipts) {
	return [...receipts].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 30).map((receipt, index) => index < 8 ? receipt : {
		...receipt,
		image: ""
	});
}
function receiptFromScan(scan, image) {
	return {
		id: createId(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		merchant: scan.merchant || "Receipt",
		date: scan.date,
		total: scan.total,
		currency: scan.currency,
		category: scan.category,
		summary: scan.summary,
		recurring: scan.recurring,
		frequency: scan.frequency,
		items: scan.items,
		billId: null,
		image,
		source: "scan"
	};
}
function receiptMonth(receipt) {
	if (/^\d{4}-\d{2}-\d{2}$/.test(receipt.date)) return receipt.date.slice(0, 7);
	return receipt.createdAt.slice(0, 7);
}
function monthLabel(month = format(/* @__PURE__ */ new Date(), "yyyy-MM")) {
	const parsed = parseISO(`${month}-01`);
	if (Number.isNaN(parsed.getTime())) return month;
	return format(parsed, "MMMM yyyy", { locale: enGB });
}
function analyseMonth(receipts, month = format(/* @__PURE__ */ new Date(), "yyyy-MM")) {
	const inMonth = receipts.filter((receipt) => receiptMonth(receipt) === month);
	const counted = inMonth.filter((receipt) => isGbp(receipt.currency));
	const total = roundMoney(counted.reduce((sum, receipt) => sum + receipt.total, 0));
	const linked = roundMoney(counted.filter((receipt) => receipt.billId).reduce((sum, receipt) => sum + receipt.total, 0));
	const byCategory = /* @__PURE__ */ new Map();
	for (const receipt of counted) byCategory.set(receipt.category, (byCategory.get(receipt.category) ?? 0) + receipt.total);
	const categories = [...byCategory.entries()].map(([category, amount]) => ({
		category,
		total: roundMoney(amount)
	})).sort((a, b) => b.total - a.total || a.category.localeCompare(b.category));
	return {
		month,
		label: monthLabel(month),
		count: inMonth.length,
		otherCurrencies: inMonth.length - counted.length,
		total,
		linked,
		extra: roundMoney(total - linked),
		categories
	};
}
function normaliseName(value) {
	return value.toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, " ").trim();
}
function suggestBill(merchant, bills) {
	const source = normaliseName(merchant);
	if (source.length < 3) return null;
	let best = null;
	for (const bill of bills) {
		const name = normaliseName(bill.name);
		if (name.length < 3) continue;
		let score = 0;
		if (source === name) score = 3;
		else if (source.includes(name) || name.includes(source)) score = 2;
		if (!best || score > best.score) best = {
			bill,
			score
		};
	}
	return best && best.score >= 2 ? best.bill : null;
}
function sortReceipts(receipts) {
	return [...receipts].sort((a, b) => {
		const left = a.date || a.createdAt;
		return (b.date || b.createdAt).localeCompare(left) || b.createdAt.localeCompare(a.createdAt);
	});
}
//#endregion
export { sanitizeReceipt as C, trimReceipts as D, suggestBill as E, sanitizeBill as S, sortReceipts as T, normalizeBill as _, billCategoryFor as a, receiptFromScan as b, duePhrase as c, formatMoney as d, frequencyLabel as f, monthlyTotal as g, monthlyCost as h, analyseMonth as i, filterBills as l, isSoon as m, FREQUENCIES as n, billsDueSoon as o, isGbp as p, SPEND_CATEGORIES as r, createId as s, CATEGORIES as t, formatGBP as u, parseAmount as v, sortBills as w, sampleBills as x, parseModelJson as y };
