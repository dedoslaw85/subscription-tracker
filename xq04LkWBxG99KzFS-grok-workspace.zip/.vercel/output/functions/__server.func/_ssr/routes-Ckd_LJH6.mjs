import { c as duePhrase, d as formatMoney, g as monthlyTotal, i as analyseMonth, o as billsDueSoon, u as formatGBP, w as sortBills } from "./model-kam-k2-k.mjs";
import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Plus } from "../_libs/lucide-react.mjs";
import { i as useBills } from "./router-BK993T2q.mjs";
import { n as buttonClasses } from "./button-CBrKE12v.mjs";
import { t as AppShell } from "./app-shell-BtxYIl1f.mjs";
import { t as BillCard } from "./bill-card-DakEhSFf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Ckd_LJH6.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const bills = useBills((state) => state.bills);
	const receipts = useBills((state) => state.receipts);
	const showSampleHint = useBills((state) => state.showSampleHint);
	const monthly = Math.round(monthlyTotal(bills) * 100) / 100;
	const upcoming = sortBills(bills).slice(0, 5);
	const soon = billsDueSoon(bills);
	const countLabel = bills.length === 1 ? "1 bill" : `${bills.length} bills`;
	const soonText = soon.length > 1 ? `${soon.length} bills are due today or tomorrow.` : soon[0] ? `${soon[0].name} is due ${duePhrase(soon[0].nextDue).replace(/^([A-Z])/, (letter) => letter.toLowerCase())}.` : null;
	const spend = analyseMonth(receipts);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/bill/$id",
			params: { id: "new" },
			className: buttonClasses({ variant: "primary" }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
				size: 20,
				strokeWidth: 1.75,
				"aria-hidden": true
			}), "Add new"]
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 pt-8 pb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Subscription Tracker"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 text-sm text-muted",
					children: "This month"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-4xl tracking-tight text-fg tabular-nums md:text-5xl",
					children: formatGBP(monthly)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"About ",
						formatGBP(monthly * 12),
						" a year · ",
						countLabel
					]
				}),
				showSampleHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-pretty text-muted",
					children: "Examples are filled in. Change or delete them anytime."
				}) : null,
				soonText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-card bg-accent-soft px-4 py-3 text-sm text-pretty text-accent-ink",
					children: soonText
				}) : null,
				spend.count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/scan",
					className: "mt-4 flex items-baseline justify-between gap-3 rounded-card border border-line bg-surface px-4 py-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm text-muted",
						children: "Receipts this month"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-base text-fg",
						children: spend.count === 1 ? "1 saved" : `${spend.count} saved`
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 tabular-nums text-fg",
						children: formatMoney(spend.total, "GBP")
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-10 text-lg text-fg",
					children: "Next payments"
				}),
				bills.length > 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "The soonest five. The rest are on List."
				}) : null,
				upcoming.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-card border border-line bg-surface px-5 py-8 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg text-fg",
						children: "Nothing coming up"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-pretty text-muted",
						children: "Add a bill and it will show here with its due date."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-3",
					children: upcoming.map((bill) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillCard, { bill }) }, bill.id))
				})
			]
		})
	});
}
//#endregion
export { Home as component };
