import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-CBrKE12v.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonClasses = cva("inline-flex items-center justify-center gap-2 rounded-control px-4 text-base font-medium transition-colors", {
	variants: {
		variant: {
			primary: "h-14 bg-accent text-on-accent hover:bg-accent-hover",
			quiet: "h-14 border border-line bg-surface text-fg hover:bg-accent-soft",
			subtle: "h-12 bg-transparent text-muted hover:text-fg"
		},
		full: {
			true: "w-full",
			false: ""
		}
	},
	defaultVariants: {
		variant: "primary",
		full: true
	}
});
function Button({ className, variant, full, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonClasses({
			variant,
			full
		}), className),
		...props
	});
}
//#endregion
export { buttonClasses as n, Button as t };
