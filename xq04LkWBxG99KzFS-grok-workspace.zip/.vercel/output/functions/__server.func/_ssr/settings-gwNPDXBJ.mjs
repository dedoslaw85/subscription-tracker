import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useBills, r as notifyDueBills } from "./router-BK993T2q.mjs";
import { t as Button } from "./button-CBrKE12v.mjs";
import { t as AppShell } from "./app-shell-BtxYIl1f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-gwNPDXBJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Settings() {
	const notifications = useBills((state) => state.notifications);
	const adsRemoved = useBills((state) => state.adsRemoved);
	const setNotifications = useBills((state) => state.setNotifications);
	const removeAds = useBills((state) => state.removeAds);
	const [note, setNote] = (0, import_react.useState)("");
	const [confirmAds, setConfirmAds] = (0, import_react.useState)(false);
	async function toggleNotifications() {
		if (notifications) {
			setNotifications(false);
			setNote("");
			return;
		}
		if (typeof Notification === "undefined") {
			setNote("This browser doesn’t support notifications.");
			return;
		}
		if (await Notification.requestPermission() !== "granted") {
			setNote("Notifications stay off until this browser allows them.");
			return;
		}
		setNotifications(true);
		setNote("On. You’ll get a reminder the day before, when the app is open.");
		notifyDueBills();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-8 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl text-fg",
				children: "Settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-pretty text-muted",
				children: "Kept on this device. Nothing is uploaded."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				role: "switch",
				"aria-checked": notifications,
				onClick: () => void toggleNotifications(),
				className: "mt-8 flex w-full items-center gap-4 rounded-card border border-line bg-surface px-4 py-4 text-left shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-base text-fg",
						children: "Notifications"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-pretty text-muted",
						children: "A gentle reminder the day before a bill is due, while the app is open."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `relative h-8 w-14 shrink-0 rounded-full ${notifications ? "bg-accent" : "bg-line"}`,
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 size-6 rounded-full bg-surface transition-transform ${notifications ? "translate-x-7" : "translate-x-1"}` })
				})]
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-pretty text-muted",
				children: note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 rounded-card border border-line bg-surface px-4 py-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg text-fg",
					children: "Remove ads"
				}), adsRemoved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-pretty text-muted",
					children: "The banner stays hidden on this device."
				}) : confirmAds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "The banner hides for good on this device. You won’t be charged in this browser version — a store build would be a one-time £1.99 purchase."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								removeAds();
								setConfirmAds(false);
							},
							children: "Remove ads"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: () => setConfirmAds(false),
							children: "Not now"
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: "Hide the single banner at the bottom of Home, List, and Settings."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: () => setConfirmAds(true),
						children: "Remove ads"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg text-fg",
						children: "About"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-pretty text-muted",
						children: "Subscription Tracker adds up what you pay each month, and rolls the next due date forward when a payment passes."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Version 1.0"
					})
				]
			})
		]
	}) });
}
//#endregion
export { Settings as component };
